-- Default portrayal rules file.  Called when rule file cannot be found.
-- #119

-- Main entry point for feature type.
function Default(feature, featurePortrayal, contextParameters)

	if (feature.PrimitiveType == PrimitiveType.Point or feature.PrimitiveType == PrimitiveType.MultiPoint) then
		featurePortrayal:AddInstructions('DisplayPlane:OverRADAR')
		featurePortrayal:AddInstructions('ViewingGroup:21010;DrawingPriority:30')
		featurePortrayal:AddInstructions('PointInstruction:USRPNT01')
	elseif (feature.PrimitiveType == PrimitiveType.Curve) then
		featurePortrayal:AddInstructions('DisplayPlane:OverRADAR')
		featurePortrayal:AddInstructions('ViewingGroup:21010;DrawingPriority:20')
		featurePortrayal:SimpleLineStyle('dash',0.32,'CHMGD')
		featurePortrayal:AddInstructions('LineInstruction:_simple_')
	elseif (feature.PrimitiveType == PrimitiveType.Surface) then
		featurePortrayal:AddInstructions('ViewingGroup:21010;DrawingPriority:10;DisplayPlane:UnderRADAR')
		featurePortrayal:AddInstructions('ColorFill:DNGHL,0.75')
		featurePortrayal:SimpleLineStyle('solid',0.32,'DNGHL')
		featurePortrayal:AddInstructions('LineInstruction:_simple_')
	end
	return "21010"
end
